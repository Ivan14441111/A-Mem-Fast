"""Measured OpenAI-compatible inference with a persistent, exact-request cache."""
from __future__ import annotations

from collections import defaultdict
import hashlib
import json
from pathlib import Path
import sqlite3
import threading
import time

import requests

SYSTEM_MESSAGE = "Follow the format specified in the prompt exactly. Do not add extra commentary."


def stage_for(prompt: str) -> str:
    if prompt.startswith("Analyze the following content"):
        return "analysis"
    if prompt.startswith("Evolve this new memory with its retrieved neighbors in one operation."):
        return "evolution_fused"
    if prompt.startswith("You are an AI memory evolution agent"):
        return "evolution_decision"
    if "CONNECTIONS:" in prompt:
        return "strengthen"
    if prompt.startswith("Given the new memory and its neighbor memories"):
        return "update_neighbors"
    if "generate several keywords" in prompt:
        return "query_keywords"
    if prompt.startswith("Based on the context:"):
        return "answer"
    return "other"


class SQLiteResponseCache:
    """WAL storage: each thread owns its connection; only successful responses persist."""

    def __init__(self, path: str | Path):
        self.path = str(path)
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        self._local = threading.local()
        with sqlite3.connect(self.path, timeout=30) as conn:
            conn.execute("PRAGMA journal_mode=WAL")
            conn.execute("CREATE TABLE IF NOT EXISTS responses "
                         "(key TEXT PRIMARY KEY, payload TEXT NOT NULL, response TEXT NOT NULL)")

    def connection(self):
        if not hasattr(self._local, "conn"):
            self._local.conn = sqlite3.connect(self.path, timeout=30)
        return self._local.conn

    def get(self, key):
        row = self.connection().execute("SELECT response FROM responses WHERE key=?", (key,)).fetchone()
        return json.loads(row[0]) if row else None

    def put(self, key, payload, response):
        conn = self.connection()
        with conn:
            conn.execute("INSERT OR REPLACE INTO responses VALUES (?,?,?)",
                         (key, payload, json.dumps(response, ensure_ascii=False)))


class MeasuredClient:
    """A drop-in get_completion controller. Cache is deterministic-only by default.

    `write` records a cold baseline without reading; `readwrite` permits reuse;
    `replay` never falls back to inference, making semantic comparisons auditable.
    """

    def __init__(self, base_url, model, *, cache=None, cache_mode="off", revision="",
                 temperature=0.0, seed=42, max_tokens=1000, timeout=180):
        if cache_mode not in {"off", "write", "readwrite", "replay"}:
            raise ValueError("Invalid cache mode")
        if cache_mode != "off" and cache is None:
            raise ValueError("Cache storage is required")
        if cache_mode != "off" and (temperature != 0 or not revision):
            raise ValueError("Caching requires temperature=0 and an explicit model revision")
        self.base_url = base_url.rstrip("/")
        self.model = model
        self.cache = cache
        self.cache_mode = cache_mode
        self.revision = revision
        self.temperature = temperature
        self.seed = seed
        self.max_tokens = max_tokens
        self.timeout = timeout
        self._local = threading.local()
        self._lock = threading.Lock()
        self._inflight = {}
        self.events = []

    def _session(self):
        if not hasattr(self._local, "session"):
            self._local.session = requests.Session()
        return self._local.session

    @staticmethod
    def _validate_response(result):
        """Apply the same checks to live and persisted responses."""
        try:
            choice = result["choices"][0]
            content = choice["message"]["content"]
        except (KeyError, IndexError, TypeError) as exc:
            raise ValueError("LLM response must contain a text completion") from exc
        if not isinstance(content, str) or not content.strip():
            raise ValueError("LLM returned no text")
        if choice.get("finish_reason") == "length":
            raise ValueError("LLM reached max_tokens; increase budget")
        if choice.get("finish_reason") in {"content_filter", "tool_calls", "function_call"}:
            raise ValueError("LLM did not finish a text completion")
        usage = result.get("usage")
        if usage is not None:
            if not isinstance(usage, dict):
                raise ValueError("LLM response usage must be an object")
            for field in ("prompt_tokens", "completion_tokens"):
                value = usage.get(field, 0)
                if type(value) is not int or value < 0:
                    raise ValueError("LLM token usage must be a nonnegative integer")
        return content

    def get_completion(self, prompt, temperature=0.7, *, _prefetch=False):
        # Both experiment arms deliberately use the same deterministic decoding.
        payload = {
            "model": self.model,
            "messages": [{"role": "system", "content": SYSTEM_MESSAGE},
                         {"role": "user", "content": prompt}],
            "temperature": self.temperature, "seed": self.seed,
            "max_tokens": self.max_tokens,
            "chat_template_kwargs": {"enable_thinking": False},
        }
        identity = json.dumps({"revision": self.revision, "base_url": self.base_url,
                               "request": payload},
                              sort_keys=True, ensure_ascii=False, separators=(",", ":"))
        key = hashlib.sha256(identity.encode()).hexdigest()
        event = {"stage": stage_for(prompt), "key": key, "prefetch": _prefetch, "cache_hit": False,
                 "http_requests": 0, "error": None, "http_seconds": 0.0,
                 "cache_read_seconds": 0.0, "cache_write_seconds": 0.0}
        started = time.perf_counter()
        flight = None
        if self.cache_mode in {"readwrite", "replay"}:
            with self._lock:
                flight = self._inflight.setdefault(key, [threading.Lock(), 0])
                flight[1] += 1
            flight[0].acquire()
        try:
            cache_started = time.perf_counter()
            result = self.cache.get(key) if self.cache_mode in {"readwrite", "replay"} else None
            event["cache_read_seconds"] = time.perf_counter() - cache_started
            if result is not None:
                event["cache_hit"] = True
            else:
                if self.cache_mode == "replay":
                    raise RuntimeError(f"Replay cache miss: {event['stage']} {key}")
                for attempt in range(3):
                    event["http_requests"] += 1
                    try:
                        http_started = time.perf_counter()
                        try:
                            response = self._session().post(self.base_url + "/chat/completions",
                                                            json=payload, timeout=self.timeout)
                        finally:
                            event["http_seconds"] += time.perf_counter() - http_started
                        if response.status_code == 429 or response.status_code >= 500:
                            response.raise_for_status()
                        response.raise_for_status()
                        result = response.json()
                        # Truncation and malformed responses never enter cache.
                        self._validate_response(result)
                        break
                    except (requests.Timeout, requests.ConnectionError, requests.HTTPError) as exc:
                        status = getattr(exc.response, "status_code", None) if isinstance(exc, requests.HTTPError) else None
                        retryable = (not isinstance(exc, requests.HTTPError) or
                                     status == 429 or (status is not None and status >= 500))
                        if not retryable or attempt == 2:
                            raise
                        time.sleep(0.5 * 2 ** attempt)
                if self.cache_mode in {"write", "readwrite"}:
                    cache_started = time.perf_counter()
                    self.cache.put(key, identity, result)
                    event["cache_write_seconds"] = time.perf_counter() - cache_started
            content = self._validate_response(result)
            event["usage"] = result.get("usage") or {}
            event["finish_reason"] = result["choices"][0].get("finish_reason")
            return content
        except Exception as exc:
            event["error"] = f"{type(exc).__name__}: {exc}"
            raise
        finally:
            event["seconds"] = time.perf_counter() - started
            with self._lock:
                self.events.append(event)
            if flight is not None:
                flight[0].release()
                with self._lock:
                    flight[1] -= 1
                    if flight[1] == 0:
                        self._inflight.pop(key, None)

    def summary(self):
        by_stage = defaultdict(lambda: {"logical_calls": 0, "http_requests": 0,
                                       "cache_hits": 0, "seconds_sum": 0.0,
                                       "prompt_tokens_live": 0, "completion_tokens_live": 0})
        with self._lock:
            events = tuple(self.events)
        for e in events:
            s = by_stage[e["stage"]]
            s["logical_calls"] += 1
            s["http_requests"] += e["http_requests"]
            s["cache_hits"] += int(e["cache_hit"])
            s["seconds_sum"] += e["seconds"]
            if not e["cache_hit"]:
                for kind in ("prompt", "completion"):
                    s[kind + "_tokens_live"] += e.get("usage", {}).get(kind + "_tokens", 0)
        # Quantiles describe logical-call durations (including cache/singleflight
        # waits). Summed concurrent durations are not elapsed wall-clock time.
        def latency(values):
            ordered = sorted(values)
            if not ordered:
                return {"latency_seconds_p50": 0.0, "latency_seconds_p95": 0.0,
                        "latency_seconds_max": 0.0}
            def percentile(q):
                position = (len(ordered) - 1) * q
                lower = int(position)
                upper = min(lower + 1, len(ordered) - 1)
                return ordered[lower] + (ordered[upper] - ordered[lower]) * (position - lower)
            return {"latency_seconds_p50": percentile(0.5),
                    "latency_seconds_p95": percentile(0.95),
                    "latency_seconds_max": ordered[-1]}
        for stage, summary in by_stage.items():
            summary.update(latency(e["seconds"] for e in events if e["stage"] == stage))
        return {"logical_calls": len(events),
                "upstream_calls": sum(not e["prefetch"] for e in events),
                "prefetch_calls": sum(e["prefetch"] for e in events),
                "http_requests": sum(e["http_requests"] for e in events),
                "cache_hits": sum(e["cache_hit"] for e in events),
                "errors": sum(e["error"] is not None for e in events),
                "http_seconds_sum": sum(e["http_seconds"] for e in events),
                "cache_read_seconds_sum": sum(e["cache_read_seconds"] for e in events),
                "cache_write_seconds_sum": sum(e["cache_write_seconds"] for e in events),
                "prompt_tokens_live": sum(s["prompt_tokens_live"] for s in by_stage.values()),
                "completion_tokens_live": sum(s["completion_tokens_live"] for s in by_stage.values()),
                **latency(e["seconds"] for e in events),
                "by_stage": dict(by_stage)}
